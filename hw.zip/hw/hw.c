// Hana Lee 40847074
// Rebecca Huang 42285382

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_CHAR 80
#define HEAP_SIZE 127

uint8_t heap[HEAP_SIZE] = {0};

void initialize_heap(){
    uint8_t heap_size = HEAP_SIZE;
    heap[0] = heap_size << 1;
    heap[HEAP_SIZE - 1] = heap_size << 1;
}

int free_block(int size){
    int current_ind = 0;

    // gives us size (including header + footer) and address of header
    while (current_ind < HEAP_SIZE) {
        uint8_t current_binary = heap[current_ind];
        int current_size = (current_binary >> 1);
    
        // check if block is free
        if ((int) (current_binary & 1) == 0){
            if (current_size >= size) {
                return current_ind;
            }
        }
        current_ind += current_size;        
    }
    return -1;
}

void split(int size, int addr){
    uint8_t split = size;
    split = split << 1;
    heap[addr] = split;
    heap[addr + size - 1] = split;
}

// change header + footer
int mem_malloc(int size, int addr){
    int block_size = heap[addr] >> 1;   
    int split_size = block_size - size; 
    
    uint8_t header = size;
    header = header << 1;
    header = header | 1;

    heap[addr] = header;
    heap[addr + size - 1] = header;

    // check for split
    if (split_size != 0){
        split(split_size, addr + size);
    }    
        
    return 0;
}

// get address of payload, free the blocks
int free_memory(int addr) {
    // get the addr to the header and block size
    addr = addr - 1;
    int block_size = heap[addr] >> 1;

    // set last bit to be 0 in header and footer
    heap[addr] = heap[addr] & 254;
    heap[addr + block_size - 1] = heap[addr] & 254;

    // reset freed blocks back to 0
    int i;
    for (i = addr; i < addr + block_size; i++){
        heap[i] = 0;
    }
    
    // check forward coalescing
    int next_header = addr + block_size;
    if ((int)(heap[next_header] & 1) == 0) {
        int next_block_size = heap[next_header] >> 1;
        block_size = block_size + next_block_size;
        uint8_t header = block_size;

        // update header and add footer to new size
        heap[addr] = header << 1; // free last bit
        heap[addr + block_size - 1] = header << 1;
    }
    
    // check backward coalescing
    int prev_footer = addr - 1;
    if ((int)(heap[prev_footer] & 1) == 0){
        int prev_block_size = heap[prev_footer] >> 1;
        int new_block_size = block_size + prev_block_size;
        uint8_t header = new_block_size;

        // update previous header and current footer to new size
        heap[addr - prev_block_size] = header << 1;
        heap[addr + block_size - 1] = header << 1;
    }

    return 0;
}

void blocklist() {
    int current_ind = 0;
    while (current_ind < HEAP_SIZE){
        uint8_t current_header = heap[current_ind];
        int current_size = current_header >> 1;
        bool is_allocated = current_header & 1;

        if (is_allocated){
            printf("%d, %d, allocated.\n", current_ind + 1, current_size - 2);
        }
        else {
            printf("%d, %d, free.\n", current_ind + 1, current_size - 2);
        }
        current_ind += current_size;
    }
}

void writemem(int addr, char * text) {
    int i;
    for (i = addr; i < addr + strlen(text); i++){
        heap[i] = text[i - addr];        
    }
}

void printmem(int addr, int num_chars_to_print) {
    int i;
    for (i = addr; i < addr + num_chars_to_print; i++){
        printf("%02X ", heap[i]);
    }
    printf("\n");
}

int main() {
    initialize_heap();
    while (!NULL) {
        // parse through input
        char line[MAX_CHAR];
        char* args[5];

        fputs(">", stdout);
        fgets(line, sizeof(line), stdin);

        int arg_count = 0;
        char* token = strtok(line, " \n");
        while (token != NULL){
            args[arg_count] = token;
            token = strtok(NULL, " \n");
            arg_count++;
        }
        args[arg_count] = NULL;

        if (strcmp(args[0], "quit") == 0){
            break;
        }

        else if (strcmp(args[0], "malloc") == 0) {
            int addr = free_block(atoi(args[1]) + 2);
            if (addr != -1) {
                mem_malloc(atoi(args[1]) + 2, addr);
                printf("%d\n", addr + 1);
            }
        }

        else if (strcmp(args[0], "free") == 0) {
            int addr = atoi(args[1]);
            free_memory(addr);
        }

        else if (strcmp(args[0], "blocklist") == 0) {
           blocklist();
        }

        else if (strcmp(args[0], "writemem") == 0) {
            int addr = atoi(args[1]);
            char * text = args[2];
            writemem(addr, text);
        }

        else if (strcmp(args[0], "printmem") == 0) {
            int addr = atoi(args[1]);
            int num_chars_to_print = atoi(args[2]);
            printmem(addr, num_chars_to_print);
        }     
    }
    return 0;
}